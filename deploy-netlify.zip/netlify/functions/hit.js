let hits = 0;
exports.handler = async () => {
  hits += 1;
  return {
    statusCode: 200,
    headers: { "Content-Type":"application/json", "Access-Control-Allow-Origin":"*" },
    body: JSON.stringify({ ok:true, hits, ts: Date.now() })
  };
};
