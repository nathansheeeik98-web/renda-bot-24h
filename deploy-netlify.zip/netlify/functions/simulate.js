function clamp(n, a, b){ return Math.max(a, Math.min(b, n)); }
function money(n){ const v = Number(n || 0); return Math.round(v * 100) / 100; }

function simulateIncome(input){
  const capital = clamp(Number(input.capital ?? 10), 0, 100000);
  const horasDia = clamp(Number(input.horasDia ?? 2), 0, 16);
  const diasMes = clamp(Number(input.diasMes ?? 26), 1, 31);
  const perfil = (input.perfil || "normal").toLowerCase();
  const caminho = (input.caminho || "servico").toLowerCase();

  const riskMult = perfil === "conservador" ? 0.75 : perfil === "agressivo" ? 1.25 : 1.0;

  const baseByPath = {
    servico: { min: 8, max: 25 },
    afiliado: { min: 2, max: 15 },
    conteudo: { min: 1, max: 12 },
    revenda: { min: 4, max: 20 },
  };
  const p = baseByPath[caminho] || baseByPath.servico;

  const capitalBoost = clamp(1 + (Math.log10(capital + 1) / 10), 1, 1.35);

  const hourlyLow = p.min * riskMult;
  const hourlyHigh = p.max * riskMult;

  const mensalLow = hourlyLow * horasDia * diasMes * capitalBoost;
  const mensalHigh = hourlyHigh * horasDia * diasMes * capitalBoost;

  const dicas = [
    "Começo: foque em 1 canal (site/SEO ou um serviço único).",
    "Reinvista 20% do que entrar em tráfego, domínio ou conteúdo.",
    "Crie oferta clara: 'faço X por Y' e repita todo dia.",
  ];

  return {
    ok: true,
    input: { capital, horasDia, diasMes, perfil, caminho },
    estimate: {
      low: money(mensalLow),
      high: money(mensalHigh),
      note: "Estimativas educativas (não garantia). Resultados variam conforme execução e mercado."
    },
    tips: dicas
  };
}

exports.handler = async (event) => {
  try{
    const body = event.body ? JSON.parse(event.body) : {};
    const out = simulateIncome(body);
    return {
      statusCode: 200,
      headers: { "Content-Type":"application/json", "Access-Control-Allow-Origin":"*" },
      body: JSON.stringify(out),
    };
  }catch(e){
    return { statusCode: 500, body: JSON.stringify({ ok:false, error:String(e) }) };
  }
};
