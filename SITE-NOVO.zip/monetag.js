// COLE AQUI o script do Monetag (do seu painel).
// Exemplo (não use esse, pegue o seu):
// (function(){ ... })();
